import java.util.List;
import java.util.ArrayList;
import java.util.Comparator;

public class Dictionary {
	public static List <Word> lib= new ArrayList<>();			//chua cac tu
	
	public static void newWord(String eng, String vie) {	//add them tu vao tu dien
		Word a=new Word(eng,vie);
		lib.add(a);
	}
}

class sortDict implements Comparator<Word> {
	public int compare(Word a, Word b) {
		return a.word_target.compareTo(b.word_target);
	}	
}