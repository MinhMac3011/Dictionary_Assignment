import java.util.Scanner;
import java.io.*;

public class Main {
	public static void main(String[] args) {
		DictionaryManagement.insertFromFile();
		//in ra cac commands
		System.out.println("Command list:");
		try{
			Scanner sc=new Scanner(new FileInputStream("command list.txt"));
			while (sc.hasNext()) {
				System.out.println(sc.nextLine());
			}
		} catch(IOException e) {
			e.printStackTrace();
		}
		
		
		while(true) {
			System.out.println();
			System.out.print("type a command: ");
			Scanner sc=new Scanner(System.in);
			String command=sc.next();
			
			if (command.equals("add")) {
				DictionaryManagement.insertFromCommandline();
			}
			else if (command.equals("del")) {
				DictionaryManagement.deleteWord();
			}
			else if (command.equals("lup")) {
				DictionaryManagement.dictionaryLookup();
			}
			else if (command.equals("upd")) {
				DictionaryManagement.updateWord();
			}
			else if (command.equals("exf")) {
				DictionaryManagement.dictionaryExportToFile();
			}
			else if (command.equals("saw")) {
				DictionaryCommandLine.showAllWords();
			}
			else if (command.equals("sch")) {
				DictionaryCommandLine.dictionarySearcher();
			}
			else if (command.equals("adv")) {
				DictionaryCommandLine.dictionaryAdvanced();
			}
			else if (command.equals("bsc")) {
				DictionaryCommandLine.dictionaryBasic();
			}
			else if (command.equals("help")) {
				System.out.println("Command list:");
				try{
					sc=new Scanner(new FileInputStream("command list.txt"));
					while (sc.hasNext()) {
						System.out.println(sc.nextLine());
					}
				} catch(IOException e) {
					e.printStackTrace();
				}
			}
			else if (command.equals("exit")) {
				break;
			}
			else {
				System.out.println("Invalid command!");
			}
		}
	}
}