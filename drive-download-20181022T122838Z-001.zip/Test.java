import java.util.Scanner;
import java.util.List;
import java.util.ArrayList;

public class Test {
	public static void main(String[] args) {
		//DictionaryCommandLine.dictionaryBasic();	//done
		DictionaryCommandLine.dictionaryAdvanced();	//done
		
		//test ham xoa tu
		//DictionaryManagement.deleteWord();
		DictionaryCommandLine.showAllWords();	//done
		
		//test ham update
		/*DictionaryManagement.updateWord();
		DictionaryCommandLine.showAllWords();*/
		
		//test searcher
		List <Word> words=DictionaryCommandLine.dictionarySearcher();
		for (Word a:words) {
			System.out.println(a.word_target);	//done
		}
	}
}