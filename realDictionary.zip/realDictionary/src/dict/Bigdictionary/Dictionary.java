package dict.Bigdictionary;
import java.util.Vector;

public class Dictionary {
    public Vector<Word> dictionary = new Vector<Word>();
}
