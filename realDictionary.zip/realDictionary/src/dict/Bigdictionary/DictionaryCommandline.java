package dict.Bigdictionary;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;
import java.util.Vector;

public class DictionaryCommandline extends DictionaryManagement{
    public void showAllWords(Vector<Word> dictionary)
    {
        System.out.println("No\t| English\t\t| Vietnamese");
        for (int i = 0  ; i < dictionary.size() ; i ++)
        {
            System.out.println((i + 1) + "\t" + "|" + dictionary.get(i).getWord_target() + "\t\t" + "|" + dictionary.get(i).getWord_explain());
        }
    }
    public void dictionaryBasic()
    {
        //insertFromCommandline();
        showAllWords(dictionary);
    }
    public void dictionaryAdvanced() throws FileNotFoundException {
        insertFromFile();
        //showAllWords(dictionary);
        showAllWords(dictionary);
        dictionaryLookup();
    }
    public void dictionarySeacher() throws FileNotFoundException
    {
        insertFromFile();
    }
    public void show()
    {
        showAllWords(dictionary);
    }
}
