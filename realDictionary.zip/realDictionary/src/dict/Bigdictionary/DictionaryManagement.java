package dict.Bigdictionary;
import javafx.beans.binding.BooleanExpression;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;
import java.util.Dictionary.*;
public class DictionaryManagement extends Dictionary{
    public void insertFromCommandline()
    {
        String word_target;
        String word_explain;
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        for (int i = 0 ; i < n ; i ++){
        word_target = sc.next();
        word_explain = sc.nextLine();
        Word ramdom = new Word(word_target, word_explain);
        dictionary.add(ramdom);
        }
    }
    public void delete()
    {
        Scanner sc2 = new Scanner(System.in);
        String word = sc2.next();
        //int flag = 0 ;
        for (int i = 0 ;  i < dictionary.size() ; i ++)
        {
            if (dictionary.get(i).getWord_target().equals(word))
            {
                dictionary.remove(dictionary.get(i));
                //flag = 1;
                i--;
            }
            /*if ((!(dictionary.get(i).getWord_target().equals(word))) && flag == 1)
            {
                break;
            }*/
        }
    }
    public void add()
    {
        Scanner sc4 = new Scanner(System.in);
        String target_word = sc4.next();
        String expain_word = sc4.nextLine();
        Word tmp = new Word(target_word,expain_word);
        dictionary.add(tmp);
        for (int i = dictionary.size() - 2 ; i >= 0 ; i --)
        {
            if (dictionary.get(i).getWord_target().compareTo(tmp.getWord_target()) > 0)
            {
                dictionary.get(i + 1).setWord_target(dictionary.get(i).getWord_target());
                dictionary.get(i + 1).setWord_explain(dictionary.get(i).getWord_explain());
            }
            else
            {
                dictionary.get(i + 1).setWord_target(tmp.getWord_target());
                dictionary.get(i + 1).setWord_explain(tmp.getWord_explain());
                break;
            }
        }
    }

    public void OrderGiver()
    {
        Scanner sc3 = new Scanner(System.in);
        System.out.println("Nhap (delete) hoac (add) :");
        String order = sc3.next();
        if (order.equals("delete"))
        {
            System.out.println("Input delete word :");
            delete();
        }
        if (order.equals("add"))
        {
            System.out.println("Input add word_target and word_explain :");
            add();
        }
    }
    public void SortDictionary()
    {
         class WordComparator implements Comparator<Word> {
            public int compare(Word a, Word b) {
                return a.getWord_target().compareTo(b.getWord_target());
            }
        }
        Collections.sort(dictionary, new WordComparator());
    }

    public void insertFromFile() throws FileNotFoundException {
        Scanner input = new Scanner(new File("dictionaries.txt"));
        String target;
        String explain;
        while(input.hasNextLine()){
            target = input.next();
            target.toLowerCase();
            explain = input.nextLine();
            explain.toLowerCase();
            dictionary.add(new Word(target,explain));
        }
        SortDictionary();
    }
    public void dictionaryLookup()
    {
        Scanner sc2 = new Scanner(System.in);
        String word = sc2.next();
        word.toLowerCase();
        String throwback = "Doan xem";
        for (int i = 0  ; i < dictionary.size() ; i ++)
        {
                if (word.equals(dictionary.get(i).getWord_target()))
                {
                    throwback = dictionary.get(i).getWord_explain();
                }
                //System.out.println(dictionary.get(i).getWord_target() + "\t" +dictionary.get(i).getWord_explain());

        }
        System.out.println(throwback);
    }

    public void dictionaryExportToFile() throws IOException
    {
        try (PrintWriter write = new PrintWriter("printOut.txt")) {
            for (int i = 0; i < dictionary.size() ; i ++)
                write.println(dictionary.get(i));
        }

    }
    public static void main (String[] args) throws IOException {
        //DictionaryCommandline execute = new DictionaryCommandline();
        //execute.insertFromFile();
        //execute.show();
        //execute.OrderGiver();
        //execute.show();
        //execute.OrderGiver();
        //execute.show();
        //execute.dictionaryAdvanced();
        //execute.dictionaryExportToFile();
        //execute.dictionaryBasic();

    }
}
// sort sau khi nhap file
// viet ham xoa dung sort
//viet ham searcher